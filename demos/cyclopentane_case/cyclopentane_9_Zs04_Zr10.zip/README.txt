TurboGrid whole-turbine assembly geometry (axial only)

Extract the complete ZIP. Import each stage/row/BladeGen.inf separately.
All profiles are ALREADY positioned in one global coordinate system,
with X as the rotation axis and coordinates in millimetres. Do not
apply the x_origin translation again. Each row still needs its own mesh.

REQUIRED TURBOGRID SETUP
1. Set BOTH hub and shroud Curve Type to Piece-wise linear for every row.
   The default Bspline can change this flowpath and boundary slopes.
2. Use the same Flowpath Parameterization Type across connected rows.
3. Row endwalls are cropped from the common flowpath and meet exactly.
   row_boundaries.csv gives intended mesh inlet/outlet planes in mm.
   Check both hub and shroud boundary positions against that table.
   The .inf files do NOT set TurboGrid mesh interface settings.
4. For passage-only meshes, set passage boundaries to the listed row
   ends and disable separate inlet/outlet domains. If separate domains
   are enabled, keep their passage interfaces inside the row bounds
   and ensure the complete mesh still ends at the listed planes.
   Do not fully extend a passage interface and also request an
   additional domain beyond that same end: it would have zero length.
5. Verify/save a row interface and reuse it for the adjacent row.

common/ contains the full flowpath for reference. Row imports use
their adjacent cropped hub.curve/shroud.curve, not the entire turbine.
Only the first/last rows have external inlet/outlet extensions.
assembly.yaml and metadata.yaml use metres and rad/s. Row ordering,
blade counts, speeds and shared interfaces are recorded there.

Span sections use free vortex and constant meridional velocity, with
absolute stator angles and relative rotor angles. Assembly profiles
include hub and shroud (no span offset); no tip clearance is prescribed.
Endwalls follow station radii with piecewise-linear gap transitions.
Inspect geometry, clearances, and mesh quality before simulation.

Import all row meshes into one CFX case and configure stationary/rotating
domains and suitable interfaces, including pitch handling for unequal
blade counts. This ZIP is geometry, NOT a coupled mesh or CFX setup.
